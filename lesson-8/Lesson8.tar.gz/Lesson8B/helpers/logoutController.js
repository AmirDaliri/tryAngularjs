angular.module('myApp').controller("logoutController",function($scope){});
console.log('logout');


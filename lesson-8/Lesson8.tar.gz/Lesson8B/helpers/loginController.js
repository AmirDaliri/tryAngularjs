app.controller("loginController",function($scope){
console.log('login');
});

